# Interactive Turkey Map


TODO:
- Mobile device support will be research
- Performance test

SUGGESTION:
- Search box option (When type city/region name in search box, city/region shows up)
- Responsive option (needs to improve SVG knowledge)
- Clickable version


[See demo](http://selengora.com/test/harita)

Note: Modalbox content does not work with file system, you need localhost or server.


**jquery interactive Turkey Map, still in progress. Thanks..

# Browser Support
- Browser compatibility test is not completed, some bugs will be all major browsers and ofcourse IE:)

# Features (Will be add)
I'm thinking add some feature to this project. Need time and ofcourse! energy for implement :p

- Active/Passive city option (default)
- Click event option (Redirect another page)
- City and Region Map option (Maybe i'm not sure yet.)
- With select box(or search box i don't know) option

# Change Log - v1.0 2015/08/11

- Modal box option
- Tooltip added (Just names showing for now)
- Active region option added
- Tooltip bug solved